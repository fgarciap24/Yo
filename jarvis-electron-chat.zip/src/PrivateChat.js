import React, { useState } from 'react';
import axios from 'axios';

function PrivateChat() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMessage = { role: 'user', content: input };
    const updatedMessages = [...messages, newMessage];

    setMessages(updatedMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await axios.post(
        'https://api.openai.com/v1/chat/completions',
        {
          model: 'gpt-4',
          messages: [{ role: 'system', content: 'Chat 100% privado' }, ...updatedMessages],
        },
        {
          headers: {
            Authorization: `Bearer TU_API_KEY_AQUI`,
            'Content-Type': 'application/json',
          },
        }
      );

      const reply = response.data.choices[0].message;
      setMessages([...updatedMessages, reply]);
    } catch (err) {
      console.error('Error en el chat privado:', err);
      alert('Error al contactar con ChatGPT.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h2>💬 Chat Privado</h2>
      <div style={{ height: 300, overflowY: 'auto', border: '1px solid #ccc', padding: 10, marginBottom: 10 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ textAlign: m.role === 'user' ? 'right' : 'left', marginBottom: 5 }}>
            <strong>{m.role === 'user' ? 'Tú:' : 'GPT:'}</strong> {m.content}
          </div>
        ))}
      </div>
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        style={{ width: '70%', padding: 8 }}
        placeholder="Escribe tu mensaje..."
      />
      <button onClick={sendMessage} disabled={loading} style={{ marginLeft: 10, padding: 8 }}>
        {loading ? '...' : 'Enviar'}
      </button>
    </div>
  );
}

export default PrivateChat;
