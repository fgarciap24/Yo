import React from 'react';
import { FaLock } from 'react-icons/fa';
import './App.css';

function App() {
  const openPrivateWindow = () => {
    window.open('/private', '_blank', 'width=600,height=700,noopener,noreferrer');
  };

  return (
    <div className="App">
      <h1>Chat Principal</h1>
      <p>Esta es la interfaz principal del asistente.</p>
      <FaLock
        onClick={openPrivateWindow}
        title="Abrir Chat Privado"
        style={{ fontSize: '32px', cursor: 'pointer', color: '#0078D4' }}
      />
    </div>
  );
}

export default App;
